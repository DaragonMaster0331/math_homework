 

## Case 1: Lens Flares, Light Leaks & Anamorphic Glow (20 Prompts)

1. Cinematic video of a warrior drawing a sword at sunset, a massive anamorphic lens flare streaking horizontally across the frame as the blade catches the golden light, haze, 35mm film.
2. A couple kissing in a convertible driving toward the camera, a warm amber light leak bleeding from the top-right corner, flaring across the lens, romantic nostalgia, 1970s Kodak.
3. Sci-fi corridor scene where a blast door opens, a blinding circular lens flare blooms from the center, washing out the image before revealing the spaceship hangar, anamorphic streaks.
4. A detective walking down a rainy alley, streetlamps creating signature blue-green anamorphic flare orbs that streak vertically across the frame, noir atmosphere, wet reflections.
5. A ballerina spinning in a studio, each rotation catching the window sun and producing a rhythmic pulse of hexagonal lens flares, dust motes dancing, ethereal backlight.
6. A motorcycle chase at golden hour, the camera lens flares violently every time the bike passes the sun, horizontal orange streaks, speed, adrenaline, anamorphic.
7. A spaceship emerging from a nebula, a prismatic lens flare splitting into rainbow spectrums across the cockpit glass, volumetric god rays, sci-fi epic.
8. A pianist's hands in close-up, a soft circular light leak pulsing from the left edge as clouds pass outside, warm golden bleed, intimate, vintage aesthetic.
9. A cowboy riding on the ridge line, the sun directly behind him creating a massive starburst flare with 12-pointed rays, silhouette, Western epic, 70mm film.
10. A fashion model turning toward camera in a studio, three distinct anamorphic flare orbs sliding horizontally as she moves, high-key beauty lighting, chrome reflections.
11. A submarine surfacing, the periscope breaking water and a blinding circular flare exploding across the frame, spray catching the dawn light, documentary cinematic.
12. A wedding couple walking through an archway, a warm amber light leak flooding the left side of the frame like a developing chemical burn, romantic, Super 8 nostalgia.
13. A sniper adjusting scope, the glint of glass creating a sharp diagonal lens flare streak across the black screen, tension, military thriller, desaturated.
14. A car driving through a tree-lined road, the sun strobing through branches creating rhythmic light leak flashes and oval flare ghosts, hypnotic motion, summer.
15. A candle being lit in a dark room, the flame immediately producing a vertical anamorphic streak flare and halation glow around the wick, intimate, horror atmosphere.
16. A surfer paddling into the sun, a massive green-blue flare washing across the water surface, sun flare reflecting off the wave face, ocean documentary, IMAX.
17. A robot's eye activating, the LED producing a sharp red anamorphic lens flare that stretches across the metal face, cyberpunk, menacing, shallow depth.
18. A ballerina in the rain, streetlights creating bokeh-iris lens flare ghosts that drift across the frame as she spins, romantic tragedy, blue-orange contrast.
19. A photographer in a darkroom, the red safelight creating a massive crimson light leak bloom from the edge of the frame, analog nostalgia, grainy, tactile.
20. A helicopter landing in snow, the rotor downwash catching the sun and creating a swirling vortex of white light and prismatic flare streaks, action, chaos.

---

## Case 2: Bokeh, Shallow Focus & Depth Transitions (20 Prompts)

1. A wine glass being filled in extreme macro, the background city lights dissolving into massive creamy bokeh orbs that pulse as the liquid rises, 85mm lens, romantic.
2. A figure walking through a Christmas market, the camera starts on the blurred lights then racks focus to reveal their tear-streaked face, emotional depth, 50mm.
3. A sniper scope view, the crosshairs tack-sharp while the world behind dissolves into circular military bokeh, breath visible, tension, telephoto compression.
4. A firefly landing on a fingertip, the background meadow becoming a wash of green bokeh orbs that float like lanterns, macro, twilight, magical realism.
5. A car interior at night, rain on the windshield creating dancing bokeh streaks while the passenger seat remains sharp, neon city colors bleeding, intimate.
6. A ballerina reflected in a rain puddle, the reflection sharp while the real figure above is a soft blur of bokeh motion, surreal, upside-down world.
7. A gun barrel in the foreground, the confession happening behind it completely dissolved into creamy bokeh blobs of tungsten light, interrogation, thriller.
8. A violin bow in sharp focus, the orchestra behind melting into warm golden bokeh circles that bounce with the music, concert hall, romantic, 85mm.
9. A bride walking down an aisle, the camera stays on the groom's face in sharp focus while she approaches through layers of soft bokeh, anticipation, love.
10. A hand reaching through a wall of hanging crystals, each out-of-focus crystal becoming a hexagonal bokeh prism, luxury, tactile, product aesthetic.
11. A moth circling a bare bulb, the room beyond reduced to creamy bokeh darkness, wings sharp, dust motes, claustrophobic, horror.
12. A coffee cup steam in sharp focus, the cafe window behind dissolving into circular morning bokeh of passing commuters, quiet solitude, 50mm.
13. A gunfight in a hall of mirrors, the real figures sharp while their reflections become soft bokeh ghosts, disorienting, action, shattered glass.
14. A child's hand holding a dandelion, the backyard dissolving into creamy green and yellow bokeh bubbles, innocence, summer, macro lens.
15. A motorcycle headlight in sharp focus, the road beyond a streak of motion-blurred bokeh, night ride, freedom, adrenaline, anamorphic.
16. A dewdrop on a spiderweb, the meadow behind the web a wash of circular bokeh orbs in pastel sunrise colors, macro, nature, peaceful.
17. A couple dancing in a ballroom, the camera circles them while chandelier bokeh orbs spin around the frame, romance, movement, 35mm.
18. A knife on a kitchen counter in sharp focus, the silhouette of a figure in the doorway completely blurred to menacing bokeh, Hitchcock tension, thriller.
19. A flower in a gun barrel, the battlefield behind dissolved to creamy bokeh smoke, anti-war symbolism, shallow depth, poetic.
20. A cat's eye in extreme close-up, the room behind reflected in the iris but dissolved to bokeh, feline, mysterious, intimate.

---

## Case 3: Slow Motion, Speed Ramping & Time Manipulation (20 Prompts)

1. A glass shattering on concrete, the impact at 1000fps, each shard catching the sunlight and spinning in crystal-clear slow motion, prismatic rain, violence.
2. A boxing knockout punch, the fist connects and the face ripples in extreme slow motion, sweat droplets flying like bullets, then snap to normal speed as the body falls.
3. A hummingbird feeding, wings frozen in strobing slow motion, each feather visible, then ramping to real time as it darts away, macro nature, high speed.
4. A car crash test, the moment of impact at 10,000fps, the metal crumpling like paper, glass blooming, then ramping to normal as debris settles, documentary.
5. A dancer's grand jeté, the apex held in silky slow motion as hair and fabric float, then ramping down to landing speed, grace, athletic beauty.
6. A match igniting, the flame blooming in slow motion, the wood grain blackening, embers floating upward, then ramping to normal as the fire catches.
7. A water balloon hitting a face, the membrane wrapping around the features in slow motion before bursting, comedic timing, summer fun, high speed.
8. A military breaching charge, the door frame exploding into splinters, each piece rotating in slow motion, dust blooming, then ramping to tactical entry speed.
9. A dolphin breaching, the water sheeting off its body in slow motion arcs, droplets frozen in sunbeams, then normal speed as it crashes back.
10. A chef's knife through a tomato, the skin dimpled before the cut, the interior revealed in slow motion, juice blooming, then ramping to rapid chopping.
11. A gun firing underwater, the gas bubble expanding in slow motion, bullet carving a cavitation tunnel, then ramping to normal as turbulence takes over.
12. A kiss in the rain, the droplets suspended in slow motion between their faces, then ramping to real time as they embrace, romantic, cinematic.
13. A skateboarder landing a trick, the board flexing and wheels compressing in slow motion, pebbles flying, then snap to normal speed on the roll away.
14. A lion taking down prey, the muscles rippling in slow motion, dust from the impact, then ramping to real time for the struggle, wildlife epic.
15. A balloon popping in a room full of confetti, the latex shredding in slow motion, paper fluttering, then chaos at normal speed, celebration.
16. A surfer inside a barrel wave, the lip of the wave throwing in slow motion, spray frozen, then ramping to normal as the wave crashes down.
17. A teardrop falling from a chin, the surface tension stretching in slow motion, the splash on fabric, then real time as the crying continues, emotional.
18. A rocket launch, the engines igniting in slow motion, ice falling from the hull, then ramping to normal speed as it climbs, NASA, epic scale.
19. A martial artist breaking a board, the wood fibers separating in slow motion, dust motes, then snap to normal as the pieces fly, power.
20. A flower blooming in time-lapse, petals unfurling in silky smooth motion, then ramping to slow motion as a bee lands, pollination, nature documentary.

---

## Case 4: Color Grading & Stylized Palettes (20 Prompts)

1. A cyberpunk street scene graded in toxic neon green and magenta, the shadows crushed to black, highlights clipping to pure color, electric atmosphere.
2. A 1940s noir scene graded in silver-gelatin monochrome, the shadows pooling to absolute black, the highlights held to a warm white, cigarette smoke curling.
3. A desert romance graded in bleach bypass, the blacks lifted to grey, the colors desaturated to sand and bone, the sky a harsh white, film grain.
4. A submarine interior graded in sickly sodium-vapor orange, every surface tinged with the emergency light, the shadows going to deep teal, claustrophobic.
5. A fashion editorial graded in pastel candy colors, the shadows lifted to soft grey, skin tones porcelain, the world looking like a马卡龙, surreal.
6. A post-apocalyptic wasteland graded in sepia and desaturated green, the sky a nuclear yellow, the shadows going to warm brown, contamination aesthetic.
7. A horror basement graded in moonlight blue, the shadows pushing to cyan, the highlights remaining cold white, every face looking cadaverous.
8. A Caribbean heist graded in teal and orange blockbuster, the skin tones warm and poppy, the water and shadows pushed to deep cyan, sun-drenched.
9. A 1970s living room graded in Kodachrome saturation, the reds bleeding slightly, the greens going to forest, the yellows blooming, nostalgic warmth.
10. A sci-fi medical bay graded in sterile white with cyan accents, the shadows kept clean grey, the skin tones slightly cool, clinical perfection.
11. A Venetian carnival graded in deep crimson and gold, the shadows rich burgundy, the highlights warm amber, painterly, Baroque chiaroscuro.
12. A winter war scene graded in desaturated blue-grey, the skin tones robbed of warmth, the snow blown out to pure white, survival, bleak.
13. A neon-drenched Tokyo alley graded in electric violet and hot pink, the blacks crushed, the rain catching every color as reflective highlights, cyberpunk.
14. A Western duel graded in golden hour amber, the shadows long and warm, the highlights clipping to honey, the sky a gradient from peach to lavender.
15. A deep-sea dive graded in bioluminescent blue-green, the shadows absolute black, the highlights catching phosphorescent cyan and green, alien.
16. A 1960s espionage film graded in cool silver and warm tungsten contrast, the interiors amber, the exteriors steel blue, stylish period aesthetic.
17. A forest witch scene graded in poison green and bruised purple, the skin taking an unhealthy pallor, the shadows going to deep violet, fairy tale horror.
18. A space opera bridge graded in warm amber console light against cold starlight blue, the faces warm, the void outside cyan, dramatic contrast.
19. A rainy London chase graded in desaturated olive and steel grey, the neon signs the only saturated reds, a sickly green cast on wet pavement, grime.
20. A tropical sunset romance graded in peach, magenta, and lavender, the shadows lifted to warm purple, the highlights glowing golden, Instagram-filtered dream.

---

## Case 5: Film Grain, Vintage Texture & Degradation (20 Prompts)

1. A 1970s family picnic shot on 16mm reversal film, the grain dancing like a living thing, the colors slightly shifted toward green, the registration wavering.
2. A World War II combat scene on degraded 35mm stock, scratches running vertically, the grain heavy in the shadows, emulsion damage flaring white.
3. A home video aesthetic from a 1990s camcorder, the interlaced scan lines visible, chromatic smearing on movement, the color bleeding to video noise.
4. A grindhouse exploitation scene with cigarette burn cue marks flashing in the upper-right corner, heavy grain, splice jumps, and color fading to magenta.
5. A silent film sequence with variable shutter flicker, the grain boiling, dust motes and hair scratches, tinted amber in the highlights, piano accompaniment implied.
6. A documentary interview on expired 35mm stock, the grain chunky and irregular, the colors shifting unpredictably, light leaks pulsing, authentic imperfection.
7. A music video on Super 8 film, the grain swirling like snow, the focus hunting, the exposure pulsing with each frame, lo-fi nostalgia, dreamlike.
8. A surveillance camera on degraded tape, the chroma crawling horizontally, the image dropping to static briefly, timecode burning in, VHS texture.
9. A 1950s Hollywood melodrama on Eastmancolor, the grain fine but present, the blacks slightly milky, the reds bleeding, velvet textures, glamour.
10. A found footage horror on consumer DV tape, the autofocus hunting, the tape dropout creating digital blocks, the audio desynchronized, raw fear.
11. A Italian neorealist scene on gritty 35mm, the grain heavy in the available darkness, the contrast harsh, the faces textured with life, post-war truth.
12. A 1980s aerobics video on Betamax, the color smearing on neon spandex, tracking lines rolling, the image slightly oversaturated, kitsch nostalgia.
13. A newsreel on degraded 16mm, the grain dancing, the audio hissing, the frame line slipping, history compressed to flickering silver.
14. A contemporary drama printed to look like 1970s 35mm, the grain structured and beautiful, the shadows greenish, the highlights blooming, filmic.
15. A dashcam on a rainy night, the MPEG compression artifacts visible, the headlights smearing into macro blocks, the timestamp glitching, digital raw.
16. A French New Wave scene on handheld 16mm, the grain organic and breathing, the blacks rich, the whites blown, jump cuts, freedom, youth.
17. A wedding video from a 1990s Hi8 camcorder, the colors warm but noisy, the image soft, the zoom motorized and slow, familial nostalgia.
18. A kung fu film on badly preserved 35mm, the grain strobing in fight scenes, the color timing inconsistent, splice marks every few minutes, Shaw Brothers.
19. A nature documentary on 16mm wildlife stock, the grain fine but present in the dawn light, the colors saturated, the image alive, Attenborough era.
20. A modern film with 65mm IMAX grain, the texture invisible in the bright exteriors but blooming in the shadows, velvety, epic, pristine yet analog.

---

## Case 6: Vignetting, Letterboxing & Frame Effects (20 Prompts)

1. A romance scene with a heavy circular vignette closing in as the couple parts, the edges going to black, the center holding the last light, emotional.
2. A Western with a 2.39:1 anamorphic letterbox, the black bars framing the wide prairie, the sky taking two-thirds of the frame, epic scale.
3. A memory sequence with rounded 16mm frame corners, the edges darkened, the center bright, like looking through a View-Master, childhood nostalgia.
4. A claustrophobic thriller where the vignette slowly tightens throughout the scene, the edges closing in, the breathing space shrinking, anxiety.
5. A 1980s action film with a 4:3 center extraction and blurred edges, pan-and-scan aesthetic, the composition fighting the frame, retro.
6. A dream sequence with a soft feathered vignette, the edges dissolving to white instead of black, ethereal, heaven-like, the center floating.
7. A documentary with a 1.37:1 Academy ratio frame, the black bars on the sides, the faces centered, the composition classical, humanistic.
8. A horror scene with a vignette that pulses with the heartbeat, the edges going dark and light rhythmically, the center holding the threat, tension.
9. A split-screen with three vertical frames, each a different angle of the same moment, the black bars dividing the action, temporal experimentation.
10. A scope film with the top and bottom bars slowly widening during a revelation, the image becoming a thin strip of reality, wider world implied.
11. A vintage film with a flickering border of film perforations visible, the frame line shifting, the image unstable, projectionist aesthetic.
12. A love letter read with the image in a soft oval vignette, like an old portrait, the edges black and romantic, the words in voiceover.
13. A security camera feed with a circular fisheye vignette and timestamp burn-in, the edges distorted, the center surveillance, found footage.
14. A European art film with a 1.66:1 ratio, the介于 Academy and widescreen, the framing balanced, the black bars subtle, contemplative.
15. A death scene with the vignette closing to a pinprick of light, the tunnel vision of consciousness fading, the edges absolute black, finality.
16. A music video with multiple aspect ratios cutting rapidly, 4:3 to 2.39 to 1:1, the frame becoming a rhythmic element, visual percussion.
17. A projected film with the image flickering and the black bars slightly uneven, the top bar drifting, the imperfect reality of cinema.
18. A scene viewed through binoculars, the circular frame with a sharp edge, the black surround absolute, the center magnified, spy thriller.
19. A mobile phone video with vertical 9:16 bars on the sides in a widescreen presentation, the black bars emphasizing the isolation of the device.
20. A climactic scene with the letterbox bars slowly burning away to reveal full frame IMAX, the world expanding, the breath catching, scale.

---

## Case 7: Chromatic Aberration, Distortion & Warping (20 Prompts)

1. A psychedelic sequence where chromatic aberration splits the red and blue channels at the edges, the world breathing in color fringes, hallucination.
2. A high-speed car chase with barrel distortion on the wide lens, the road bending at the edges, the center speed, the periphery warped, adrenaline.
3. A drunken POV with severe chromatic aberration and radial blur, the red and cyan edges separating with every movement, disorientation, nausea.
4. A sci-fi force field where the air chromatically separates into rainbow edges, the distortion rippling outward from the center, energy, power.
5. A fisheye lens view from a peephole, the world bending spherically, the chromatic aberration at the extreme edges, paranoia, thriller.
6. A heat wave in the desert, the mirage creating chromatic splitting and vertical waviness, the horizon liquid, the colors separating, survival.
7. A cyberpunk city seen through a cheap lens, heavy purple and green fringing on every neon sign, the distortion adding grime, low-tech future.
8. An underwater scene where the water pressure creates chromatic aberration and pincushion distortion, the colors splitting at the edges, deep blue.
9. A horror scene where the ghost's presence warps the image, chromatic aberration bleeding from the figure, the barrel distortion bending walls, supernatural.
10. A GoPro action shot with heavy fisheye distortion, the horizon bending, the subject at center sharp, the world wrapping around them, extreme.
11. A vintage anamorphic lens with heavy purple fringing on high-contrast edges, the bokeh ovals stretched, the distortion adding character, 1970s.
12. A concussion scene, the camera tumbling, chromatic aberration splitting the image into RGB channels, the world warping, disorientation, trauma.
13. A macro shot through a water droplet, the world inverted and chromatically separated, the edges prismatic, the center magical, nature.
14. A night vision scope with green phosphor and edge distortion, the chromatic aberration adding to the cheap-tech feel, military, tension.
15. A shattered glass POV, the image fractured and each shard carrying its own chromatic shift and distortion, kaleidoscopic, violence.
16. A time travel sequence with chromatic aberration strobing and the image pinching at the center, the world folding, sci-fi, energy.
17. A cheap security camera with rolling shutter distortion and color bleeding, the image warping on movement, the edges fringing, found footage.
18. A dream sequence with gentle chromatic aberration and a breathing warp, the walls softening, the colors separating slightly, unreal, sleep.
19. An extreme wide-angle skate video, the handrail bending dramatically at the edges, the skater center, the world distorted, youth culture.
20. A crystal ball prediction, the image inside the sphere chromatically inverted and warped, the edges prismatic, the center showing fate.

---

## Case 8: Atmospheric Haze, Fog, Smoke & Volumetrics (20 Prompts)

1. A medieval battlefield at dawn, the ground fog rolling in thick and white, soldiers emerging from nothing, volumetric god rays, swords catching light.
2. A noir alley where cigarette smoke catches the shaft of a single streetlamp, the volumetric beam cutting through darkness, mystery, rain.
3. A spaceship corridor with emergency smoke filling the frame, the volumetric lights from panels creating visible beams, panic, sci-fi, claustrophobic.
4. A forest witch's cottage, the dry ice fog pooling at the ground, lacing through the trees, the lantern light catching the haze, fairy tale.
5. A concert stage with haze from a fog machine, the spotlights becoming visible blades of light, the crowd hands cutting through beams, music.
6. A winter river where steam rises thickly, the sun backlit through the fog, the volumetric mist rolling and glowing, Japan, peaceful, zen.
7. A burning building interior, the smoke thick and black near the ceiling, the firefighter's flashlight beam visible in the haze, heat distortion, danger.
8. A Victorian séance, the incense smoke curling and catching candlelight, faces appearing and disappearing in the haze, spiritualism, horror.
9. A tropical morning where the humidity creates ground fog in the rice terraces, the layers of mist separating the fields, Bali, ethereal.
10. A war zone with smoke from distant fires drifting across the golden hour sun, the volumetric beams turning orange, dust, desolation.
11. A cryogenic chamber opening, the liquid nitrogen fog spilling out in heavy white clouds, the figure emerging, sci-fi, mystery, cold.
12. A rainy street at night where car headlights create three-dimensional beams through the mist, the haze glowing neon, reflections, cyberpunk.
13. A western ghost town at dawn, dust devils and morning fog mixing, the saloon visible through the haze, a rider emerging, spaghetti western.
14. A deep-sea submersible, the particles in the water catching the spotlight beams, marine snow creating volumetric depth, abyssal, mystery.
15. A bakery kitchen, the steam from the ovens filling the frame, the warm light catching the flour dust, golden, tactile, morning ritual.
16. A gothic cathedral with incense smoke rising and catching stained glass light, the beams of colored volumetric light, sacred, ancient.
17. A post-apocalyptic highway where radioactive fog glows faintly green, the Geiger counter clicking, the haze obscuring the horizon, dread.
18. A jazz club where the smoke catches the amber stage lights, the saxophone player visible through the haze, the air thick, nostalgia.
19. A mountain valley where clouds pour over the ridge like a waterfall, the volumetric mist rolling through trees, Tibet, spiritual, vast.
20. A laboratory explosion, the chemical smoke billowing in colored clouds, emergency lights catching the haze, chaos, science gone wrong.

---

## Case 9: Motion Blur, Strobe Light & Shutter Effects (20 Prompts)

1. A high-speed train passing a platform, the train a horizontal streak of motion blur while the waiting figure stays sharp, transience, longing.
2. A boxer punching a speed bag, the bag a circular blur of motion, the fists sharp at the points of impact, rhythm, training, sweat.
3. A dance floor under strobe lights, the dancers frozen in sharp slices of time between black frames, the motion blur of arms, rhythmic disorientation.
4. A car chase with a low shutter speed, the background streaking horizontally while the car stays relatively sharp, speed, night, neon trails.
5. A helicopter rotor, the blades a complete disc of motion blur, the pilot visible through the transparency, military, power, vertigo.
6. A carnival ride at night, the lights creating circular motion blur trails, the riders frozen in sharp moments by the flash, joy, chaos.
7. A martial artist performing a kata, the staff a continuous blur of motion, the body sharp at the center, discipline, long exposure feel.
8. A subway train arriving, the motion blur of the cars streaking, the advertisements smearing to color fields, urban, daily life, anonymity.
9. A punk concert with the strobe cutting to black between frames, the crowd frozen mid-jump, the motion blur of hair and limbs, energy.
10. A waterfall where the long exposure turns the water to silk, the rocks sharp and timeless, the contrast of motion and stillness, nature.
11. A fire spinner, the flames creating continuous circular motion blur, the spinner's face illuminated by the glow, ritual, night, danger.
12. A sprint at the Olympics, the shutter speed catching the athletes sharp but the background and limbs streaking, determination, finish line.
13. A DJ turntable, the spinning vinyl a motion blur, the tone arm sharp, the strobe dots creating a visual rhythm, music, tactile.
14. A night battle with muzzle flashes strobing the darkness, the soldiers frozen in flash frames, the motion blur of tracers, war, chaos.
15. A figure skater's spin, the arms a horizontal blur, the face at center composed, the ice spray a frozen cloud, grace, athleticism.
16. A freeway at night from an overpass, the headlights and taillights creating red and white motion blur streaks, urban bloodstream, time-lapse.
17. A ballet fouetté turn, the tutu a perfect circular motion blur, the supporting leg sharp, the arms tracing, classical, pirouette.
18. A lightning storm with strobe-like natural flashes, the landscape frozen in sharp monochrome between darkness, the trees bending, power.
19. A slot car race, the tiny cars a blur of color on the track, the track itself sharp, the hands of the controllers twitching, childhood.
20. A hummingbird's wings in strobing sunlight, the wings a grey blur, the body and flower tack sharp, the strobe of shadow, nature.

---

## Case 10: Reflections, Mirroring & Glass Refractions (20 Prompts)

1. A city skyline perfectly mirrored in a still lake, the camera slowly pulling back to reveal the reflection is actually a glass floor, vertigo, twist.
2. A detective's face reflected in the chrome of a coffee machine, the distorted convex reflection showing two angles, noir, introspection.
3. A ballerina dancing, her reflection in the polished floor a perfect mirror, the camera rotating to make it unclear which is real, surreal.
4. A car chase reflected in a series of shop windows, the glass shattering and the reflection fragmenting, action, fragmentation, violence.
5. An astronaut's helmet reflecting the lunar surface and Earth, the curved glass distorting the horizon, the face visible inside, isolation.
6. A Venetian canal scene where the water is a perfect mirror, the buildings doubled, a gondola crossing the reflection line, romantic, Italy.
7. A fashion model reflected in a wall of broken mirrors, the face fragmented into a dozen angles, beauty, destruction, high fashion.
8. A sniper scope reflected in a window, the target visible in the crosshairs and the sniper's eye visible in the glass, duality, thriller.
9. A rain-soaked street where every puddle holds a fragment of neon city light, the camera moving through reflections, urban, night, poetry.
10. A crystal chandelier casting rainbow refractions across a ballroom, the light dancing on walls and faces, the camera following the prisms, luxury.
11. A helicopter reflected in the glass towers of a city, the building becoming a kaleidoscope of sky and rotor, corporate, power, vertigo.
12. A fish seen from above and below the waterline simultaneously, the refraction bending the body, the surface a mirror, nature, documentary.
13. A gun barrel reflected in the victim's eye in extreme close-up, the eye wet and the reflection distorted, horror, final moment, intimate.
14. A desert oasis where the water mirrors the palm trees perfectly, the heat refraction making the reflection shimmer, mirage, survival, hope.
15. A dancer in a studio of mirrors, the reflections multiplying to infinity, the camera moving through the reflections, identity, performance.
16. A car's rearview mirror showing the threat approaching while the road ahead is calm, the two spaces in one frame, thriller, tension.
17. A glass skyscraper reflecting the storm clouds, the building becoming a dark mirror of the sky, nature versus architecture, epic.
18. A wine glass reflecting the candlelight and the lover's face across the table, the refraction splitting the flame, romantic, intimate.
19. A shark seen from inside a diving cage, the bars and the shark reflected in the diver's mask, the refraction of fear, underwater, terror.
20. A calm sea reflecting a sunset so perfectly the horizon disappears, the ship floating in a void of orange, surreal, peaceful, transcendence.

---

**Usage Notes:** Add "Cinematic video," "4K," "highly detailed," or your model's preferred quality prefix. These prompts are tuned for models like Stable Video Diffusion, CogVideo, Mochi, AnimateDiff, and Luma Dream Machine.